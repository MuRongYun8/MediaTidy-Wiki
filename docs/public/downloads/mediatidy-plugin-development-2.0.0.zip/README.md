# MediaTidy Python 插件开发 Skill · SDK 2.0.0

解压后将完整 mediatidy-plugin-development 文件夹导入支持 Skill 的开发工具，或先读取 SKILL.md。保留 references、agents 与 assets。

本包包含 Python SDK、同版本能力契约、文档、目录扫描/Pillow/React 模板与公开前端 SDK。作者使用 Python 3.12、uv 0.6.7 与 mypy；React 模式另需 Node 22.12+。

从 references/getting-started.md 开始，将 references/sdk[dev] 安装到作者虚拟环境，复制 assets 中的模板并执行 python -m mt_plugin pack。SDK 不得加入插件运行依赖。

安装 Skill 不会安装或启用插件，也不会授予宿主能力。插件和依赖属于受信任代码。
