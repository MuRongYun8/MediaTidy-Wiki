# MediaTidy 插件开发 Skill · SDK 2.0.0

解压后将完整的 mediatidy-plugin-development 文件夹导入支持 Skill 的 AI 开发工具。Codex 用户可复制到 ~/.codex/skills/；也可以让 AI 直接读取文件夹中的 SKILL.md。必须保留 references 与 agents 子目录。

本包包含完整 Skill、同版本 SDK 文档与 TypeScript 类型，不包含模型、账号配置、平台二进制或已安装插件。SDK 开发工具和 Goja 运行器的准备方法见 references/tooling.md。

官方 Wiki：https://murongyun8.github.io/MediaTidy-Wiki/plugins/

安装 Skill 不会安装或启用 MT 插件，也不会授予目录、定时、HTTP 或整理权限。
