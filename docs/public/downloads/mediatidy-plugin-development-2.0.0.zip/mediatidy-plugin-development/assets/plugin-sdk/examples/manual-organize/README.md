# 授权目录、配置保存与单文件整理

使用 Python 3.12、同版本 SDK 和 uv，执行 `python -m mt_plugin check`、`python -m mt_plugin pack`。
测试前使用独立测试 MT 实例、临时媒体和专用整理方案；提交按钮会真实执行授权方案，可能移动、覆盖或清理文件。

流程：宿主 DirectoryPicker 返回 `rootId + 相对路径`，保存动作重新检查目录及方案授权，只有 `storage.set` 成功才报告保存成功。页面重开时读取已保存设置，初始化不覆盖用户值。

文件查询通过 `files.list` 分页获取真实 `ref`，每次只对用户点击的文件调用 `organize.manual.run`。电视剧逐文件核对季集；不把整个目录绑定为同一作品。提交后登记 `tasks.wait` 并立即返回，由内部完成动作读取最终状态。

`files.roots()` 返回数组，条目有 `id/name/storageType/read/write/delete`，没有绝对路径。空数组提示到设置与授权中配置；异常保持原错误码和字段位置，不转换成空数组，也不从绝对路径猜根目录。

本示例演示单目录分页和单文件提交。大规模任务应先读取 `runtime.info` 的限制，分区扫描和分批执行；不要把全部文件引用、结果或日志装进页面状态。

开发测试可使用 `mt_plugin.testing.ContractTransport` 配置离线响应与失败，不访问真实云盘。模拟契约通过仍需验证真实宿主的权限、任务和生命周期行为。
