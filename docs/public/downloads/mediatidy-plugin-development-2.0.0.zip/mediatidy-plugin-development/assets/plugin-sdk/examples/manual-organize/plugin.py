"""Browse an authorized directory, save settings, and explicitly organize one file."""
from mt_plugin import Plugin as BasePlugin, Context, SDKError, action, query, continuation, ui


class Plugin(BasePlugin):
    def get_page(self, ctx: Context):
        roots = ctx.mt.files.roots()  # An array of IDs and permissions, without absolute paths.
        saved = ctx.mt.storage.get(key='settings')
        settings: dict = saved.get('value', {}) if saved['found'] else {}
        if not isinstance(settings, dict) or settings.get('schemaVersion', 1) != 1:
            raise SDKError('配置格式不兼容，请在数据与存储中恢复备份', 'CONFIG_INVALID')
        return ui.page(
            ui.Alert(text='请先在设置与授权中授予读取目录、存储及整理方案。', tone='warning', visible=not bool(roots)),
            ui.DirectoryPicker(label='作品所在目录', bind='state.directory'),
            ui.ProfilePicker(label='整理方案', bind='state.profileId'),
            ui.Button(label='保存目录与方案', onClick=[{'type':'invoke', 'actionId':'save', 'input':{
                'directory':ui.ref('state.directory'), 'profileId':ui.ref('state.profileId')}}]),
            ui.Input(label='TMDB ID', type='number', bind='state.tmdbId'),
            ui.Select(label='作品类型', bind='state.mediaType', options=[{'label':'电影','value':'movie'}, {'label':'电视剧','value':'tv'}]),
            ui.Input(label='季号（电视剧）', type='number', bind='state.season'),
            ui.Input(label='集号（电视剧，每次核对当前文件）', type='number', bind='state.episode'),
            ui.Alert(text='点击文件对应的提交按钮会直接执行整理。请核对作品、季集和方案；方案可能移动、覆盖或清理文件。', tone='warning'),
            ui.Text(text=ui.ref('query.files.data.message')),
            ui.Table(source=ui.ref('query.files.data.items'), rowKey='ref', pageSize=20, columns=[
                {'label':'文件', 'field':'name', 'cells':[]},
                {'label':'操作', 'cells':[ui.Button(label='提交这个文件', onClick=[{'type':'invoke', 'actionId':'submit', 'input':{
                    'fileRef':ui.ref('row.ref'), 'profileId':ui.ref('state.profileId'), 'tmdbId':ui.ref('state.tmdbId'),
                    'mediaType':ui.ref('state.mediaType'), 'season':ui.ref('state.season'), 'episode':ui.ref('state.episode')}}])]},
            ]),
            ui.Button(label='刷新首页', onClick=[{'type':'set','path':'state.page','value':1}, {'type':'query','queryId':'files'}]),
            ui.Button(label='下一页', disabled=ui.expr('not', ui.ref('query.files.data.hasMore')),
                onClick=[{'type':'set','path':'state.page','value':ui.ref('query.files.data.nextPage')}]),
            ui.RunHistory(),
            state={'directory':settings.get('directory'), 'profileId':settings.get('profileId', 0),
                   'tmdbId':0, 'mediaType':'movie', 'season':1, 'episode':1, 'page':1},
            queries=[{'id':'files','name':'files','input':{'directory':ui.ref('state.directory'),'page':ui.ref('state.page')}}],
        )

    @action('save')
    def save(self, input: dict, ctx: Context):
        directory = input['directory']
        # Recheck the current grant and directory before saving the selection.
        ctx.mt.files.list(root_id=directory['rootId'], path=directory['path'], page=1)
        if input['profileId'] not in ctx.mt.runtime.resources()['organizeProfileIds']:
            raise SDKError('请选择已授权的整理方案', 'PERMISSION_DENIED', path='input.profileId')
        ctx.mt.storage.set(key='settings', value={'schemaVersion':1, 'directory':directory, 'profileId':input['profileId']})
        return {'saved':True, 'message':'目录与方案已保存'}  # Only after the write succeeds.

    @query('files')
    def files(self, input: dict, ctx: Context):
        directory = input.get('directory')
        if directory is None:
            return {'items':[], 'hasMore':False, 'nextPage':1, 'message':'请选择作品目录'}
        if not isinstance(directory, dict) or not isinstance(directory.get('rootId'), str) or not isinstance(directory.get('path'), str):
            raise SDKError('目录选择已失效，请重新选择', 'INVALID_ARGUMENT', path='input.directory')
        result = ctx.mt.files.list(root_id=directory['rootId'], path=directory['path'], page=input['page'])
        return {'items':[item for item in result['items'] if not item['isDir']], 'hasMore':result['hasMore'],
                'nextPage':input['page'] + 1, 'message':'只显示当前页文件；目录不会自动递归或批量提交'}

    @action('submit')
    def submit(self, input: dict, ctx: Context):
        payload = {key:input[key] for key in ('fileRef','profileId','tmdbId','mediaType')}
        if input['mediaType'] == 'tv':
            for key in ('season', 'episode'):
                if key not in input:
                    raise SDKError('电视剧需要逐文件提供完整季集', 'INVALID_ARGUMENT', path=f'input.{key}')
            payload.update(season=input['season'], episode=input['episode'])
        payload['idempotencyKey'] = f"{ctx.flow_id}:{input['fileRef']}"
        task = ctx.mt.organize.manual.run(payload)
        ctx.mt.tasks.wait(refs=[task['ref']], completion={'action':'collect', 'input':{}})
        return {'taskRef':task['ref'], 'waiting':True}

    @continuation('collect')
    def collect(self, input: dict, ctx: Context):
        tasks = ctx.event['tasks']
        ok = bool(tasks) and all(task['status'] == 'done' for task in tasks)
        return {'ok':ok, 'message':'整理已完成' if ok else '整理未成功完成，请核对任务状态；结果未知时不要自动重试'}
