---
name: mediatidy-plugin-development
description: 开发、迁移和排查 MediaTidy Python SDK v2 插件，包括清单、常驻生命周期、任务续接、Python 组件或 React 页面、依赖与 ZIP 打包。用于 MediaTidy 插件作者任务，不用于修改无关主应用功能。
---

# MediaTidy Python 插件开发

以随包契约和目标宿主实现为准。入口为 `plugin.py:Plugin`，继承 `mt_plugin.Plugin`；`sdkVersion` 与 `ui.version` 都是字符串 `"2"`。旧 Goja/JS 插件即使声明 SDK v2，也需要迁移入口、页面和依赖。

## 开始工作

确认用户要创建、修改还是排查插件，先读现有清单、处理函数和相关测试。保留用户选择的 UI 模式和既有业务；只在能力或执行范围确实不明时澄清。主仓库可用时对照当前实现；只有本包时用随包契约，不能假定旧宿主已支持所有新字段。

- 环境、模板与打包：[快速开始](references/getting-started.md)。
- 清单、schema、Python/JSON 命名：[清单与参数](references/manifest.md)。
- 方法参数、权限、限额和允许通道：[methods.json](references/sdk/mt_plugin/methods.json)；实现入口是 [clients.py](references/sdk/mt_plugin/clients.py)。
- Python 组件属性：[ui-registry.json](references/sdk/mt_plugin/ui-registry.json)。

## 选择随包资源

默认从 [目录扫描模板](assets/plugin-sdk/starter/README.md) 复制到用户工作目录，SDK 位于 `references/sdk/`。安装作者依赖：在插件虚拟环境中安装 `<本 Skill>/references/sdk[dev]`，之后用 `uv run --no-sync python -m mt_plugin pack`。Python 固定 3.12，uv 固定 0.6.7；不要将宿主 SDK 加入插件运行依赖或锁文件。

- 图片处理使用 [Pillow 示例](assets/plugin-sdk/examples/pillow/README.md)。
- Emby 海报下载、合成、预览与上传使用 [Emby 海报示例](assets/plugin-sdk/examples/emby-poster/README.md)，并读 [临时图片](references/artifacts.md) 和 [Emby 文件传输](references/emby.md#文件上传与下载)。
- Table 行内操作、大结果分键与游标分页使用 [存储表格示例](assets/plugin-sdk/examples/storage-table/README.md)，并读 [存储](references/storage.md) 和 [UI](references/ui.md)。保留扫描 ID、失败状态及行 ID 传参，避免将存储失败显示为零结果。
- React 使用 [React 示例](assets/plugin-sdk/examples/react/README.md) 与 [公开前端 SDK](assets/plugin-frontend-sdk/package.json)，并读 [UI](references/ui.md)。保留 assets 下目录层次时本地依赖可直接解析；搬走模板后重设依赖并更新锁文件。React 作者另需 Node 22.12+，默认 Python 作者不需要。
- 本包不含 AI 插件源码。处理其业务时阅读 [AI 工作流](references/ai-organize.md)，在可用的主仓库中检查 `mediatidy-plugin-template/`，不要凭旧示例重建已变更的行为。

## 实现时遵守的契约

- 同步函数用 `ctx.mt`，异步函数用 `await ctx.amt`。Python 方法和顶层关键字使用 snake_case；嵌套字典仍用契约 camelCase。不要混用字典与普通关键字以为会自动合并。
- 每个公开动作、查询、内部续接均与清单一一对应。`validate_config` 纯校验；查询和页面只读。业务与读取通道可能并行访问常驻对象，跨重启状态放 KV 或 data_dir。
- 耗时操作保存宿主 task ref。调用 `tasks.wait` 后立即返回；完成函数用 `@continuation` 且清单标记 `kind: continuation`。排队不等于成功，续接检查最终任务状态。见[生命周期](references/automation.md)。
- 触发器使用清单稳定 key；schedule upsert 使用 `declarationKey`，event upsert 使用 `key`。新增默认暂停，重建保留用户暂停状态。
- 文件使用有效宿主引用、授权根及相对路径，不能把不同挂载路由或绝对路径混用。二进制通过工作文件传输，目录、方案、版本与权限最终由宿主校验。见[业务接口](references/business.md)、[权限](references/permissions.md)。
- 仅判断 SHA1 是否已有本地 FF 缓存时，使用 `ffprobe.cache_exists(sha1=...)` 并单独声明 `ffprobe.cache.exists`。只返回布尔值，不代表 FF 数据完整；查询失败保留错误。目标宿主须支持此新增能力，详见[业务接口](references/business.md#查询本地-ff-缓存是否存在)。
- 复用 MT 的 Emby 配置时，声明 `emby.api` 并由用户授权服务器；使用 `emby.servers.list()` 和 `emby.request(...)`。MT 自动鉴权，不读取 API Key；通用请求仅用于动作，检查返回的 HTTP 状态，写操作超时后先核对远端结果。文件下载使用 `response_type="file"`，图片上传使用 `body_file/body_ref`、对应 `content_type` 及 Emby 要求的 `body_encoding="base64"`。参数与示例见 [Emby](references/emby.md)。
- 动作结束会清理 `work_dir`。生成图片需跨动作预览或上传时，先用 `artifacts.publish(path=...)` 接管为实例专属临时引用，页面使用 `file:<ref>` 或 React `mt.previewUrl(ref)`；此流程需 `storage` 权限。限额、过期及清理见[临时图片](references/artifacts.md)，不能根据插件自写提示推断所有工作台页面全面禁止 Base64。
- 直接整理选 `organize.manual.run`；人工审阅选 `organize.manual.prepare/prepare_batch` 和宿主 DraftReview，保留 `organize.prepare/organize.submit` 授权。未知提交先核对原任务，不重放；稳定幂等键不复用于不同请求。
- 批量流程先检查 `runtime.info().limits.maxWorkflowFiles`；缺失时按 100 处理。当前上限 500，列表页仍最多 100，AI 示例每批 8。分项持久化和分页显示，避免把全部明细塞进运行摘要。见[容量](references/workflow-capacity.md)。
- AI 原生搜索必须同时启用 `single_request=True` 和 `native_web_search=True`，并有 `ai.chat/ai.web.search` 授权。该模式失败不自动重发或降级；搜索来源缺失与 TMDB 身份核对失败不同。不要把 AI 示例特有的一次识别规则强加给未选择该模式的插件。
- 配置草稿显式保存，日志记录阶段和可定位错误，避免凭据、私有链接与敏感请求。见[存储](references/storage.md)、[日志](references/logs.md)。

插件与依赖是受信任原生代码；虚拟环境和 SDK 授权不是安全沙箱，React 与主站共享 JavaScript。宿主上传检查只读数据；作者 check/pack 会导入源码并可能构建 React，不能对不可信上传包执行作者 CLI。

## 验证与交付

按[验收](references/validation.md)选择与改动相关的检查：清单/装饰器一致、schema、Python 类型、依赖锁和 ZIP；有主仓库时补宿主包检查。业务用隔离数据及模拟服务测试，覆盖取消、部分失败、续接、幂等和未知提交。UI 在实际宿主检查页面及失败后的管理入口。

安装与打包故障先按文件名、字段路径、处理函数差异和阶段排查，见[开发工具](references/tooling.md)。已安装文件损坏时用可信原包执行修复安装，保留配置、授权及数据；修改源码则重新打包更新，不编辑安装目录或重算其完整性标识。UI 严格使用注册表属性；`Button.size`、`Button.loading` 和 `DirectoryPicker` 需要支持对应字段或组件的宿主。最新完整包与使用说明见[下载开发 Skill](references/downloads.md)，更新 Skill 不会升级宿主。

交付源码、插件 ZIP、必要授权说明及已验证/未验证范围。区分本地模拟与真实服务结果；开发请求不包含推送、正式发布、启用生产插件、真实云端操作或外部通知授权。排错先定位依赖、生命周期、页面、SDK 或业务任务阶段，避免把失败包装成成功。

## 稳定性与常用交互约定

- `on_init` 只补缺失的 Storage 值；更新沿用实例与业务数据，不可每次重置配置。`found` 与值是否为空不同。
- 默认值使用页面 `state`。选择目录使用 `ui.DirectoryPicker(bind="state.directory")`，写入目标使用 `access="write"`；保存 `{rootId, path}`，通过 `files.roots()` 感知授权目录，不硬编码宿主路径。
- Button 的请求加载态由宿主处理；后台业务状态可用 `loading=ui.ref(...)` 或表达式绑定。未知属性仍会校验失败，请确认宿主支持这些组件。
- `tasks.wait`（或异步版本）之后立即返回；日志、进度与存储调用放在等待登记之前。
- 配置仅声明 `configSchema` 时，可从宿主设置编辑 JSON 并修复错误；保留最终校验，不建议放开错误态插件页面或绕过授权。
- UI 契约与用法以 [UI 文档](references/ui.md)、[存储说明](references/storage.md) 和 [校验说明](references/validation.md) 为准。
