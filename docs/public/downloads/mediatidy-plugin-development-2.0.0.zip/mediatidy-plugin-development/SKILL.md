---
name: mediatidy-plugin-development
description: 开发、修改和验证 MediaTidy SDK v2 插件，使用 MT 的文件、媒体业务、任务调度、存储及组件页面协议。适用于插件功能和开发排错，不负责修改 MT 核心或发布插件。
---

# MediaTidy 插件开发

本 Skill 随 SDK 2.0.0 分发。先检查插件 `sdkVersion:"2"`，页面协议 `ui.version:"1"`。使用同版本 [能力清单](references/capabilities.md) 与 [完整类型](references/index.d.ts)，不要沿用旧 AI 模板或猜测接口。

根据用户要实现的业务选择最少能力和资源，完成可运行代码、页面、验证及使用说明。已有插件先读取清单、动作和测试；新插件使用开发包的 `mt-plugin init` 通用目录清单。不要为普通业务创建宿主专用插件 ID 分支。

- 文件、规则、整理、STRM、评分、外部服务：读 [业务接口](references/business.md) 和 [权限](references/permissions.md)。配置与规则只读；公开配置不等于数据库配置。
- 定时、取消、等待业务结果：读 [调度与事件](references/automation.md)。异步业务返回持久任务引用；登记 `tasks.wait` 后立即返回。不要写轮询等待或插件 Cron 服务。
- 跨运行数据、密钥、回退格式：读 [存储](references/storage.md)。使用 `found` 区分不存在与 null；并发更新用 revision；数据格式自行版本化，勿自动回退或清空。
- 页面、Logo、表格：读 [页面协议](references/ui.md) 和 [UI 类型](references/ui-schema.d.ts)。只构建 JSON，不能注入 React/HTML/CSS/表达式。整理确认由 MT 生成。
- 构建、模拟、Goja、本地预览：读 [工具](references/tooling.md) 和 [入门](references/getting-started.md)。开发机可构建，MT 安装时不执行仓库脚本。

业务入口是同步 `module.exports.run(input)`，只能调用 `mt` JSON SDK。不能使用 Node、fetch、系统命令、环境变量、SQL、宿主文件路径或任意 URL 抓取。耗时变更使用稳定幂等键；`OUTCOME_UNKNOWN` 不自动重试，清理业务存储不能改变安全记录。

远程 FF 是受保护资产，包括宿主落盘缓存。评分只使用授权文件引用与方案，输出业务总分、资格、完整状态和比较结果。不新增探测数据导出、逐维评分、任意 SHA1、权重或字段查询。用户授权目录内普通 STRM/NFO/文本按授权处理；避免把宿主密钥和日志误当用户文件。

验证与改动对应的行为：类型与协议检查、真实 Goja 场景、任务/存储隔离、取消及部分失败、页面主题和手机视口。使用带标记的假 FF 数据检查不泄漏；使用模拟服务，不依赖真实凭据。模拟通过不能证明真实 AI 或云盘正确。

交付说明列出需要用户授予的目录/方案/通道/HTTP 目标、验证结果和未验证环境。保留现有用户数据与不相关改动。用户要求开发不等于授权启用定时、扩大权限、修改本机插件授权、发送通知或发布远端仓库/npm 包。
